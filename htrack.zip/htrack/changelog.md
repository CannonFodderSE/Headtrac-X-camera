# HeadTrack Changelog

Made with <3 in Scotland by Amy Alex Parent.  
(c) 2020 Amy Parent <developer@amyparent.com>

[github.com/amyinorbit/headtrack][github]  
[ko-fi.com/amyinorbit][ko-fi]

## 2311.1.1

* This is not an official patch.  amyinorbit has not yet approved it.
* added Mark Ellis' (https://github.com/markcellis) X-Camera patch (https://github.com/amyinorbit/headtrack/pull/5/files).

## 2209.1

* add support for arm64 on macOS (X-Plane 12)
* use Sašo Kiselkov's libacfutils library.

## 2012.3.0

* [fix] rotation and translation axes were inverted in settings files. *You will need to check and arrange your settings.*

## 2012.3.0

* first experimental macOS build
* motion range controls are replaced with more intuitive sensitivity ones
* [fix] the settings window shows head tracking data even when the simulator view isn't tracked.
* [fix] per-plane settings are now saved and loaded correctly.

## 2012.2.1

* [fix] running HeadTrack without Headshake installed now works properly.

## 2012.2.0

* Initial test version

 [github]: https://github.com/amyinorbit/headtrack
 [ko-fi]: https://ko-fi.com/amyinorbit
